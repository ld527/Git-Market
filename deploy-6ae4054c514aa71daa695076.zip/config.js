// ضع بيانات مشروع Supabase هنا. استخدم Project URL و anon/public key فقط.
// لا تضع service_role key في هذا الملف أو في أي كود يعمل داخل المتصفح.
window.GLOW_CONFIG = {
  supabaseUrl: 'YOUR_SUPABASE_PROJECT_URL',
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_PUBLIC_KEY'
};
