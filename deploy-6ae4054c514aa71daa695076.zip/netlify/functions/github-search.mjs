// GitHub Search proxy for GLOW MARKET.
// Keep GITHUB_TOKEN in Netlify environment variables; never expose it to the browser.
export default async (request) => {
  const url = new URL(request.url);
  const q = (url.searchParams.get('q') || 'stars:>1000').trim();
  const page = Math.max(1, Math.min(83, Number.parseInt(url.searchParams.get('page') || '1', 10) || 1));

  if (!q || q.length > 220) {
    return json({ error: 'عبارة البحث غير صالحة أو طويلة جداً.' }, 400);
  }

  const headers = {
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent': 'Glow-Market'
  };
  const token = process.env.GITHUB_TOKEN;
  if (token) headers.Authorization = `Bearer ${token}`;

  try {
    const api = new URL('https://api.github.com/search/repositories');
    api.searchParams.set('q', q);
    api.searchParams.set('sort', 'stars');
    api.searchParams.set('order', 'desc');
    api.searchParams.set('per_page', '12');
    api.searchParams.set('page', String(page));

    const upstream = await fetch(api, { headers });
    const body = await upstream.text();
    const responseHeaders = {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    };
    for (const name of ['x-ratelimit-limit', 'x-ratelimit-remaining', 'x-ratelimit-reset', 'x-ratelimit-resource']) {
      const value = upstream.headers.get(name);
      if (value) responseHeaders[name.replace('x-ratelimit-', 'x-github-ratelimit-')] = value;
    }
    responseHeaders['x-github-authenticated'] = token ? 'true' : 'false';
    return new Response(body, { status: upstream.status, headers: responseHeaders });
  } catch {
    return json({ error: 'تعذر الاتصال بخدمة GitHub. حاول مرة أخرى بعد قليل.' }, 502);
  }
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
  });
}
